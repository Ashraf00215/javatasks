import java.util.Scanner;
public class ascii_code 
{
    public static void main (string[] args)
    {
        system.out.println("Enter the ascii code : ");
        Scanner sc= new Scanner(System.in); 
        int a= sc.nextInt(); 
        char letter = a;
        system.out.println("the letter is : " + letter);
    }
}